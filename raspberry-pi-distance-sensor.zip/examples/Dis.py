import RPi.GPIO as GPIO
import time


class sonicDitance:
    def __init__(self,trig,echo):
        GPIO.setmode(GPIO.BCM)
        self.TRIG = trig
        self.ECHO = echo
        GPIO.setup(self.TRIG, GPIO.OUT)
        GPIO.setup(self.ECHO, GPIO.IN)

    def hello():
        print("Cool")
        

    def mesureDistance(self):
            GPIO.output(self.TRIG, True)
            time.sleep(0.0001)
            GPIO.output(self.TRIG, False)

            while GPIO.input(self.ECHO) == False:
                    start = time.time()
                    
            while GPIO.input(self.ECHO) == True:
                    end = time.time()
                    
            sig_time = end-start

            distance = sig_time / 0.000058
            return('Distance: {} cm'.format(distance))
	
