import time

import Adafruit_Nokia_LCD as LCD
import Adafruit_GPIO.SPI as SPI
import Dis as dis
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw

# Hardware SPI usage:
#Creates a new instance of Adafruit_Nokia_LCD.
disp = LCD.PCD8544(DC, RST, spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE, max_speed_hz=4000000))

# Initialize library.
disp.begin(contrast=55)

# Clear display.
disp.clear()
disp.display()

# Load image and convert to 1 bit color.
image = Image.open('happycat_lcd.ppm').convert('1')

# Alternatively load a different format image, resize it, and convert to 1 bit color.
#image = Image.open('happycat.png').resize((LCD.LCDWIDTH, LCD.LCDHEIGHT), Image.ANTIALIAS).convert('1')

# Display image.
disp.image(image)
disp.display()
#end of example code. from this point on the code will use distance.

time.sleep(5)

image = Image.new('1', (LCD.LCDWIDTH, LCD.LCDHEIGHT))
font = ImageFont.load_default()

#Uses dis.py.
disObj = dis.sonicDitance(4,18)

#printing the distance forever.
while True:
    draw = ImageDraw.Draw(image)
    draw.rectangle((0,0,83,47), outline=255, fill=255)
    disp.clear()
    text = disObj.mesureDistance()
    print(text)

    # we can only print one char at once, so we do this manualy. a fun challenge will be so create a function that prints a string intead of char.
    xpos = 0
    for i in range(0,len(text)):
            width, height = draw.textsize(text[i], font=font)
            draw.text((xpos, 20), text[i], font=font, fill=0)
            xpos+=width

    disp.image(image)
    disp.display()
    time.sleep(0.1)
    #wait 0.1 seconds between itterations.

